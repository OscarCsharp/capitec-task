import { Routes } from '@angular/router';
import { AppointmentComponent } from './modules/appointment/appointment.component';
import { AuthGuard } from './middleware/auth.guard';
import { LoginComponent } from './modules/login/login.component';
import { PermissionsComponent } from './modules/permissions/permissions.component';
import { TransactionsComponent } from './modules/transactions/transactions.component';
import { TabMenuComponent } from './modules/tab-menu/tab-menu.component';
import { InvoiceListComponent } from './modules/invoice-list/invoice-list.component';


export const routes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: 'appointments', component: AppointmentComponent, canActivate: [AuthGuard] },
    { path: 'transactions', component: TransactionsComponent , canActivate: [AuthGuard]},
    { path: 'tabmenu', component: TabMenuComponent , canActivate: [AuthGuard]},
    { path: 'invoices', component: InvoiceListComponent , canActivate: [AuthGuard]},
    { path: 'no-permissions', component: PermissionsComponent },
    { path: '**', redirectTo: 'login' }
  ];
  
