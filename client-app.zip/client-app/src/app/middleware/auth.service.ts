import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = `${environment.apiBaseUrl}/authentication/login`;

  constructor(private http: HttpClient, private router: Router) {}

  login(credentials: { username: string; password: string }): Observable<any> {
    const formData = new FormData();
    formData.append('UserName', credentials.username); 
    formData.append('Password', credentials.password); 
    return this.http.post(this.apiUrl, formData);
  }

  setToken(token: string): void {
    sessionStorage.setItem('authToken', token);
  }

  getToken(): string | null {
    return sessionStorage.getItem('authToken');
  }

  logout(): void {
    sessionStorage.removeItem('authToken');
    this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getUserRole(): string | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload?.role || null;
    } catch (e) {
      console.error('Invalid token format', e);
      return null;
    }
  }
  
  getLoggedInUserId(): string | null {
    const token = this.getToken();
   
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload?.user_id || '';
    } catch (e) {
      console.error('Invalid token format', e);
      return null;
    }
  }


  getUser(): { id: string; name: string; email: string } | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return {
        id: payload?.sub || payload?.nameidentifier || '',
        name: payload?.unique_name || '',
        email: payload?.email || ''
      };
    } catch (e) {
      console.error('Invalid token format', e);
      return null;
    }
  }
}