import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../middleware/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm!: FormGroup; 
  errorMessage: string | null = null;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
 
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) return;

    const credentials = {
      username: this.loginForm.value.username!,
      password: this.loginForm.value.password!
    };

    console.log('Attempting login with credentials:', credentials);
    this.authService.login(credentials).subscribe({
      next: (response: any) => { 
        const token = response.token;
        this.authService.setToken(token);
        const role = this.authService.getUserRole();

        if (role === "user") {
          this.router.navigate(['/tabmenu']);
        } 
        if(role === "admin"){
          this.router.navigate(['/invoices']);
        }
        /*else {
          this.router.navigate(['/no-permissions']);
        }*/
      },
      error: (err) => {
        console.error('Login error:', err);
        this.errorMessage = 'Invalid username or password.';
      }
    });
  }
}

