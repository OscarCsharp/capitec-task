import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppointmentComponent } from "../appointment/appointment.component";
import { TransactionsComponent } from "../transactions/transactions.component";

@Component({
  selector: 'app-tab-menu',
  imports: [CommonModule, FormsModule, AppointmentComponent, TransactionsComponent],
  templateUrl: './tab-menu.component.html',
  styleUrl: './tab-menu.component.css'
})
export class TabMenuComponent {
  activeTab: 'appointments' | 'transactions' = 'appointments';

  setTab(tab: 'appointments' | 'transactions') {
    this.activeTab = tab;
  }
}
