import { Component, OnInit } from '@angular/core';
import { Appointment } from '../../models/appointment.model';
import { AppointmentService } from '../../services/appointment.service';
import { BranchService } from '../../services/branch.service';
import { Branch } from '../../models/branch.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../middleware/auth.service';
import { AddAppointment } from '../../models/addAppointment.model';

@Component({
  selector: 'app-appointment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [AppointmentService, BranchService],
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {
  appointments: Appointment[] = [];
  branches: Branch[] = [];

  newAppointment: AddAppointment = {
    customerId: '',
    branchId: '',
    scheduledDate: new Date(),
    isConfirmed: false
  };

  selectedAppointment: Appointment | null = null;
  userId = '';

  constructor(
    private appointmentService: AppointmentService,
    private branchService: BranchService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.userId = this.authService.getLoggedInUserId() ?? '';
    this.loadBranches();
    this.loadAppointments();
    this.newAppointment.customerId = this.userId;
  }

  loadAppointments(): void {
    if (!this.userId) {
      console.warn('User ID is missing, cannot load appointments.');
      return;
    }

    this.appointmentService.getAppointmentsByUserId(this.userId).subscribe({
      next: (data) => {
        this.appointments = data;
      },
      error: (err) => {
        console.error('Failed to load appointments:', err);
      }
    });
  } 

  loadBranches(): void {
    this.branchService.getAll().subscribe(data => {
      this.branches = data;
    });
  }

  createAppointment(): void {
    const appointment: AddAppointment = {
      customerId: this.userId,
      branchId: this.newAppointment.branchId,
      scheduledDate: this.newAppointment.scheduledDate,
      isConfirmed: this.newAppointment.isConfirmed
    };

    this.appointmentService.add(appointment).subscribe(() => {
      this.newAppointment = {
        customerId: this.userId,
        branchId: '',
        scheduledDate: new Date(),
        isConfirmed: false
      };
      this.loadAppointments();
    });
  }

  editAppointment(appointment: Appointment): void {
    this.selectedAppointment = { ...appointment };
  }

  updateAppointment(): void {
    if (this.selectedAppointment) {
      this.appointmentService.update(this.selectedAppointment.appointmentId, this.selectedAppointment)
        .subscribe(() => {
          this.loadAppointments();
          this.selectedAppointment = null;
        });
    }
  }

  getBranchName(branchId: string): string {
    const branch = this.branches.find(b => b.branchId === branchId);
    return branch ? branch.name : branchId;
  }
}
