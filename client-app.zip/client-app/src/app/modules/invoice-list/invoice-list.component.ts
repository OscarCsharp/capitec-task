import { Component, OnInit } from '@angular/core';
import { InvoiceService } from '../../services/invoice.service';
import { InvoiceModel } from '../../models/invoice.model';
import { InvoiceNotificationModel } from '../../models/invoiceNotification.model';
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../middleware/auth.service';

@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrls: ['./invoice-list.component.css'],
  imports:[CommonModule, FormsModule, DatePipe, CurrencyPipe]
})
export class InvoiceListComponent implements OnInit {
  invoices: InvoiceModel[] = [];
  notifications: InvoiceNotificationModel[] = [];
  unreadCount = 0;
  showModal = false;
  userId = '';

  newInvoice: InvoiceModel = {
    businessId: '',
    invoiceNumber: '',
    issueDate: new Date(),
    dueDate: new Date(),
    amount: 0,
    isPaid: false
  };

  constructor(private invoiceService: InvoiceService, private authService: AuthService) {}

  ngOnInit(): void {
    this.userId = this.authService.getLoggedInUserId() ?? '';
    this.loadInvoices();
    this.loadNotifications();
  }

  loadInvoices(): void {
    this.invoiceService.getAllInvoices().subscribe({
      next: (data) => this.invoices = data,
      error: (err) => console.error('Error loading invoices', err)
    });
  }

  loadNotifications(): void {
    this.invoiceService.getAllInvoiceNotifications().subscribe({
      next: (data) => {
        this.notifications = data;
        this.updateUnreadCount();
      },
      error: (err) => console.error('Error loading notifications', err)
    });
  }

  updateUnreadCount(): void {
    this.unreadCount = this.notifications.filter(n => !n.isRead).length;
  }

  isOverdue(invoice: InvoiceModel): boolean {
    return new Date(invoice.dueDate) < new Date() && !invoice.isPaid;
  }

  openModal(): void {
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
    this.resetForm();
  }

  addInvoice(): void {
    this.newInvoice.businessId = this.userId;
    this.invoiceService.addInvoice(this.newInvoice).subscribe({
      next: (createdInvoice) => {
        this.invoices.push(createdInvoice); 
        this.closeModal();
      },
      error: (err) => console.error('Error adding invoice', err)
    });
  }

  resetForm(): void {
    this.newInvoice = {
      businessId: '',
      invoiceNumber: '',
      issueDate: new Date(),
      dueDate: new Date(),
      amount: 0,
      isPaid: false
    };
  }

  markAsRead(note: InvoiceNotificationModel): void {
    note.isRead = true;
    this.invoiceService.updateInvoiceNotification(note.invoiceNotificationId, note).subscribe({
      next: () => this.updateUnreadCount(),
      error: (err) => console.error('Error marking notification as read', err)
    });
  }
}