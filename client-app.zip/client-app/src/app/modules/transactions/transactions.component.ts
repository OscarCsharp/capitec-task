import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../../services/transaction.service';
import { TransactionModel } from '../../models/transaction.model';
import { TransactionDisputeModel } from '../../models/transactiondispute.model';
import { AuthService } from '../../middleware/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-transactions',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  transactions: TransactionModel[] = [];
  showModal = false;
  showDisputeModal = false;
  filter: 'all' | 'disputed' | 'notDisputed' = 'all';

  newTransaction: TransactionModel = {
    transactionId:'',
    customerId: '',
    amount: 0,
    bankName: '',
    accountType: '',
    accountNumber: '',
    referenceNumber: '',
    isDisputed: false
  };

  selectedTransaction: TransactionModel | null = null;
  disputeReason: string = '';

  bankList: string[] = ['ABSA', 'FNB', 'Standard Bank', 'Nedbank', 'Capitec'];
  accountTypes: string[] = ['Savings', 'Cheque', 'Business', 'Student'];
  userId = '';

  constructor(
    private transactionService: TransactionService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.userId = this.authService.getLoggedInUserId() ?? '';
    this.loadTransactions();
  }

  loadTransactions(): void {
    this.transactionService.getUserTransactions( this.userId).subscribe({
      next: (data) => this.transactions = data,
      error: (err) => console.error('Error loading transactions', err)
    });
  }

  get filteredTransactions(): TransactionModel[] {
    if (this.filter === 'disputed') {
      return this.transactions.filter(tx => tx.isDisputed);
    } else if (this.filter === 'notDisputed') {
      return this.transactions.filter(tx => !tx.isDisputed);
    }
    return this.transactions;
  }

  openModal(): void {
    this.newTransaction = {
      customerId: this.authService.getLoggedInUserId() ?? '',
      transactionId:'',
      amount: 0,
      bankName: '',
      accountType: '',
      accountNumber: '',
      referenceNumber: '',
      isDisputed: false
    };
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
  }

  addTransaction(): void {
    this.transactionService.addTransaction(this.newTransaction).subscribe({
      next: () => {
        this.loadTransactions();
        this.closeModal();
      },
      error: (err) => console.error('Error adding transaction', err)
    });
  }

  openDisputeModal(tx: TransactionModel): void {
    this.selectedTransaction = tx;
    this.disputeReason = '';
    this.showDisputeModal = true;
  }

  closeDisputeModal(): void {
    this.showDisputeModal = false;
    this.selectedTransaction = null;
    this.disputeReason = '';
  }

  submitDispute(): void {
    if (!this.selectedTransaction || !this.disputeReason.trim()) return;

    const disputeModel: TransactionDisputeModel = {
      customerId: this.authService.getLoggedInUserId() ?? '',
      transactionId: this.selectedTransaction.transactionId,
      reason: this.disputeReason,
      submittedBy: this.authService.getLoggedInUserId() ?? ''
    };

    this.transactionService.addTransactionDispute(disputeModel).subscribe({
      next: () => {
        this.loadTransactions();
        this.closeDisputeModal();
      },
      error: (err) => console.error('Error submitting dispute', err)
    });
  }
}