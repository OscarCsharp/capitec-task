import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { AddAppointment } from '../models/addAppointment.model';

export interface Appointment {
  appointmentId: string;
  customerId: string;
  branchId: string;
  scheduledDate: Date;
  isConfirmed: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private apiUrl = `${environment.apiBaseUrl}/appointment`;

  constructor(private http: HttpClient) {}

  getAllAppointments(): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(`${this.apiUrl}/getAllAppointments`);
  }
  
getAppointmentsByUserId(userId: string): Observable<Appointment[]> {
  return this.http.get<Appointment[]>(`${this.apiUrl}/userAppointments/${userId}`);
}

  add(appointment: AddAppointment): Observable<any> {
    return this.http.post(`${this.apiUrl}/addAppointment`, appointment);
  }

  update(appointmentId: string, appointment: Appointment): Observable<any> {
    return this.http.put(`${this.apiUrl}/updateAppointment/${appointmentId}`, appointment);
  }

  delete(appointmentIdOrUserId: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/removeAppointment/${appointmentIdOrUserId}`);
  }

}