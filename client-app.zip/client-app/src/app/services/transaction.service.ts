import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { TransactionModel } from '../models/transaction.model';
import { TransactionDisputeModel } from '../models/transactiondispute.model';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private baseUrl = `${environment.apiBaseUrl}/transaction`;

  constructor(private http: HttpClient) {}

  // Transactions
  getAllTransactions(): Observable<TransactionModel[]> {
    return this.http.get<TransactionModel[]>(`${this.baseUrl}/GetAllTransactions`);
  }
  
  getUserTransactions(userId: string): Observable<TransactionModel[]> {
    return this.http.get<TransactionModel[]>(`${this.baseUrl}/GetUserTransactions/${userId}`);
  }

  getTransaction(searchTerm: string): Observable<TransactionModel> {
    return this.http.get<TransactionModel>(`${this.baseUrl}/GetTransaction/${searchTerm}`);
  }

  addTransaction(model: TransactionModel): Observable<any> {
    return this.http.post(`${this.baseUrl}/AddTransaction`, model);
  }

  updateTransaction(id: string, model: TransactionModel): Observable<any> {
    return this.http.put(`${this.baseUrl}/UpdateTransaction/${id}`, model);
  }

  removeTransaction(id: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/RemoveTransaction/${id}`);
  }

  // Disputes
  getAllTransactionDisputes(): Observable<TransactionDisputeModel[]> {
    return this.http.get<TransactionDisputeModel[]>(`${this.baseUrl}/GetAllTransactionDisputes`);
  }

  getDispute(searchTerm: string): Observable<TransactionDisputeModel> {
    return this.http.get<TransactionDisputeModel>(`${this.baseUrl}/GetDispute/${searchTerm}`);
  }

  addTransactionDispute(model: TransactionDisputeModel): Observable<any> {
    return this.http.post(`${this.baseUrl}/AddTransactionDispute`, model);
  }

  updateTransactionDispute(id: string, model: TransactionDisputeModel): Observable<any> {
    return this.http.put(`${this.baseUrl}/UpdateTransactionDispute/${id}`, model);
  }

  removeTransactionDispute(id: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/RemoveTransactionDispute/${id}`);
  }
}
