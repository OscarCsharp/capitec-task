import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { InvoiceModel } from '../models/invoice.model';
import { InvoiceNotificationModel } from '../models/invoiceNotification.model';


@Injectable({ providedIn: 'root' })
export class InvoiceService {
  private apiUrl = `${environment.apiBaseUrl}/Invoice`;

  constructor(private http: HttpClient) {}

  // ---------------- Invoice Endpoints ----------------
  addInvoice(model: InvoiceModel): Observable<any> {
    return this.http.post(`${this.apiUrl}/AddInvoice`, model);
  }

  getAllInvoices(): Observable<InvoiceModel[]> {
    return this.http.get<InvoiceModel[]>(`${this.apiUrl}/GetAllInvoices`);
  }

  getInvoice(searchTerm: string): Observable<InvoiceModel> {
    return this.http.get<InvoiceModel>(`${this.apiUrl}/GetInvoice/${searchTerm}`);
  }

  updateInvoice(invoiceId: string, model: InvoiceModel): Observable<any> {
    return this.http.put(`${this.apiUrl}/UpdateInvoice/${invoiceId}`, model);
  }

  deleteInvoice(invoiceId: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/DeleteInvoice/${invoiceId}`);
  }

  // ---------------- Notification Endpoints ----------------
  addInvoiceNotification(model: InvoiceNotificationModel): Observable<any> {
    return this.http.post(`${this.apiUrl}/AddInvoiceNotification`, model);
  }

  getAllInvoiceNotifications(): Observable<InvoiceNotificationModel[]> {
    return this.http.get<InvoiceNotificationModel[]>(`${this.apiUrl}/GetAllInvoiceNotifications`);
  }

  updateInvoiceNotification(id: string, model: InvoiceNotificationModel): Observable<any> {
    return this.http.put(`${this.apiUrl}/UpdateInvoiceNotification/${id}`, model);
  }

  deleteInvoiceNotification(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/DeleteInvoiceNotification/${id}`);
  }
}