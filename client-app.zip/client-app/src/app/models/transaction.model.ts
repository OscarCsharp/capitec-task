export interface TransactionModel {
    transactionId : string;
    customerId: string;
    amount: number;
    bankName: string; 
    accountType: string; 
    accountNumber: string;
    referenceNumber?: string;
    isDisputed : boolean ;
  }