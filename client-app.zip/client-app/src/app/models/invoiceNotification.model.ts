export interface InvoiceNotificationModel {
    invoiceNotificationId: string; 
    invoiceId: string;
    message: string;
    isRead: boolean;
    sentDate?: Date; 
  }