export interface TransactionDisputeModel {
    customerId: string;
    transactionId: string;
    reason: string;
    submittedBy: string; 
  }