export interface Branch {
    branchId: string;
    name: string;
    location: string;
  }
  