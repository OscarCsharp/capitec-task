export interface AddAppointment {
    //appointmentId: string;
    customerId: string;
    branchId: string;
    scheduledDate: Date;
    isConfirmed: boolean;
    }