export interface Appointment {
  appointmentId: string;
  customerId: string;
  branchId: string;
  scheduledDate: Date;
  isConfirmed: boolean;
  }