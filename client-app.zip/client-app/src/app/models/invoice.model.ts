export interface InvoiceModel {
    businessId: string;
    invoiceNumber: string;
    issueDate: Date;
    dueDate: Date;
    amount: number;
    isPaid: boolean;
  }